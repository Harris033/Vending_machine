package vending.machine;

import java.util.List;

/**
 * Many users, one admin
 * implementing users using an arraylist since this will let us
 * add an infinite amount of users
 */
public class machine {
    private List<User> users;
    private admin admin;
    private List<product> products;
    private float totalMoneyLeft;
    private float moneyDeposit;


    /**
     * new machine object
     * @param users list of users in the vending machine
     */
    public machine(List<User> users, List<product> products, vending.machine.admin admin) {
        this.users = users;
        this.admin = admin;
        this.products = products;
        totalMoneyLeft=0;
        moneyDeposit=0;
    }

    /**
     *
     * @return the list of users
     */
    public List<User> getUsers() {
        return users;
    }

    /**
     *
     * @return the list of products
     */

    public List<product> getProducts(){
        return products;
    }

    public vending.machine.admin getAdmin() {
        return admin;
    }

    /**
     *
     * @return total money left of the user
     */
    public float getTotalMoneyLeft() {
        return totalMoneyLeft;
    }

    /**
     * Adds a user to the machine
     * @param user the user that is added
     */
    public void addUsers(User user) {
        users.add(user);
    }

    public void addProducts(product product) {
        products.add(product);
    }

    public void setAdmin(vending.machine.admin admin) {
        this.admin = admin;
    }

    public float getMoneyDeposit() {
        return moneyDeposit;
    }


    public void updateTotalMoneyLeft(float totalMoneyLeft) {
        totalMoneyLeft= moneyDeposit;
    }


}
