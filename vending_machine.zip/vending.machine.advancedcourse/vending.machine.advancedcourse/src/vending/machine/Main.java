package vending.machine;
import java.util.ArrayList;
import java.util.List;
public class Main {
    public static void main(String[] args) {
        User harris = new User(3114263,"Harris");
        User zubair = new User(2,"Zubair");
        User elon = new User(2236,"Elon");
        List<User> userList = new ArrayList<>();
        userList.add(harris);
        userList.add(zubair);
        userList.add(elon);

        admin admin = new admin(1001, "John Doe","javaisfun");

        product coke = new product("Coke", 1.30f);
        product choc = new product("Rittersport", 1.70f);
        product crisp = new product("Pringles", 2.50f);

        List<product> productList = new ArrayList<>();
        productList.add(coke);
        productList.add(choc);
        productList.add(crisp);

        machine vend1 = new machine(userList,productList, admin);
        System.out.println("You have" + vend1.getTotalMoneyLeft() + "Euros left");



    }
}
