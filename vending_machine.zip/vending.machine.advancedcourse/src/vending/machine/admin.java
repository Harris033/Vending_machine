package vending.machine;

/**
 * Resposible for the admin login
 * features including a
 */
public class admin {
    private int id;
    private String Name;
    private String password;

    /**
     * Creates a new admin object
      * @param id id for the admin
     * @param password password for the admin
     */
    public admin(int id,String Name ,String password){
        this.id=id;
        this.Name=Name;
        this.password=password;

    }



}
