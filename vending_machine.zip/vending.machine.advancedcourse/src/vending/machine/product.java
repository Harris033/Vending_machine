package vending.machine;

/**
 * List of products and their prices.
 */
public class product {
    private String Name;
    private float price;

    public product(String name, float price) {
        Name = name;
        this.price = price;
    }
}



