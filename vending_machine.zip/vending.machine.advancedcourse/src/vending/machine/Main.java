package vending.machine;
import java.util.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
// Please use username: Harris
// password: 3114263 for running the code
public class Main {
    public static void main(String[] args) {
        User harris = new User(3114263,"Harris");
        User zubair = new User(2,"Zubair");
        User elon = new User(2236,"Elon");
        List<User> userList = new ArrayList<>();
        userList.add(harris);
        userList.add(zubair);
        userList.add(elon);

        HashMap<String, String> usrs = new HashMap<String, String>();
        usrs.put("Harris", "password1");
        usrs.put("Shefali", "password2");
        usrs.put("Khushi", "password3");

//        HashMap<String, Integer> prdct = new HashMap<String, Integer>();
//        prdct.put("coke", 1);
//        prdct.put("pringles", 5);
//        prdct.put("Rittersport", 4);



        admin admin = new admin(1001, "John Doe","javaisfun");

        product coke = new product("Coke", 1.30f);
        product choc = new product("Rittersport", 1.70f);
        product crisp = new product("Pringles", 2.50f);

        List<product> productList = new ArrayList<>();
        productList.add(coke);
        productList.add(choc);
        productList.add(crisp);

        System.out.println(" *********************************************");
        System.out.println("     WELCOME TO OUR VENDING MACHINE           ");
        System.out.println(" *********************************************");
        System.out.println("            Products available:               ");
        System.out.println(" Coke 1.30 Euros   Pringles 5.30 Euros  RitterSport 3.30 Euros Many more coming SOON!");
        System.out.println("     \t ***************************");
        System.out.println("Please identify yourself");


        machine vend1 = new machine(userList,productList, admin);
//        System.out.println("You have\t" + vend1.getTotalMoneyLeft() + "\tEuros left");

            Scanner scanner=new Scanner(System.in);
            String sysUserName="Harris";
            String sysPassword="3114263";
            String sysProduct1="Coke";
            String sysProduct2="Pringles";
            String sysProduct3="RitterSport";
            float sysPrice1= 1.30F;
            float sysPrice2= 5.30F;
            float sysPrice3= 3.30F;

            System.out.print("Enter username: ");
            String userName=scanner.next();

            System.out.print("Enter password(Student id): ");
            String password=scanner.next();

//            if(sysUserName.equals(userName)){
//                if(sysPassword.equals(password)){
//                    System.out.println("Welcome User");
//                }else{
//                    System.out.println("Please check Password");
//                    System.exit(0);
//
//                }
//
//            }
//Code for Hash map----------------
            if (usrs.containsKey(userName) ){
                String pass = String.valueOf(usrs.get(userName));
                String pass2 =  password.trim();

                if (pass.compareTo(pass2) == 0){
                    System.out.println("User Verified");
                }
                else{
                    System.out.println("User not verified");
                    System.exit(0);
                }
                }


// Ends here---------------



        System.out.println("You have\t" + vend1.getTotalMoneyLeft() + "\tEuros left");
        if(vend1.getTotalMoneyLeft()<10) {
            System.out.println("You have less than 10 dollars which is the minimum balance required to place an order");
            System.out.println("Would like to deposit some money into your account. Enter 1 for YES or 0 for NO:  ");
            int ans;
            float amt;
            int productCode;
            ans = scanner.nextInt();
            if (ans == 1){
                System.out.println("Enter the amount");
                amt = scanner.nextFloat();

                vend1.addMoney(amt);
                System.out.println("You have\t" + vend1.getTotalMoneyLeft() + "\tEuros left");
                System.out.println("Enter the product name that you want to buy");
                System.out.println("Enter 1 for Coke, 2 for Pringles, 3 for Rittersport");
                productCode = scanner.nextInt();
                switch (productCode) {
                    case 1:
                        System.out.println("Enjoy you coke");
                        vend1.totalMoneyLeft= vend1.totalMoneyLeft - sysPrice1;
                        System.out.println("You have now \t" + vend1.totalMoneyLeft + "\tEuros left");
                        break;
                    case 2:
                        System.out.println("Enjoy you Pringles");
                        vend1.totalMoneyLeft= vend1.totalMoneyLeft - sysPrice2;
                        System.out.println("You have now\t" + vend1.totalMoneyLeft + "\tEuros left");
                        break;
                    case 3:
                        System.out.println("Enjoy you Rittersport");
                        vend1.totalMoneyLeft= vend1.totalMoneyLeft - sysPrice3;
                        System.out.println("You have now\t" + vend1.totalMoneyLeft + "\tEuros left");
                        break;

                }


            }
            else{

                System.out.println("Not enough money..Try again later");
            }
        }







        }


    }



