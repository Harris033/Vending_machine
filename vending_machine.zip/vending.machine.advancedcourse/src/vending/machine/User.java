package vending.machine;

/**
 * This class is responsible to create users and keep track of the
 * money that has been deposited
 * id is specific to a user
 * money desposit is money deposited by that specific user id
 */
public class User {
    private int id;
    private String Name;
    private float moneyDeposit;


    /**
     * Creating a constructor: to create a new user by initializing.
     * moneyDeposit is money added by the user.
     */
      public User(int id, String Name) {
          this.moneyDeposit=0;
          this.id=id;
          this.Name=Name;


      }

    public int getId() {
        return id;
    }

    public String getName() {
        return Name;
    }

    public float getMoneyDeposit() {
        return moneyDeposit;
    }


}
